# from diffusers import DiffusionPipeline
# import torch
# import os
# def imgGenerate(question):
#     n_steps = 40
#     high_noise_frac = 0.8
#     number_of_images=1
#     prompt = "{}(without any texts)".format(question)
#     print(prompt)
#     output_folder = "/bk_image_folder"
#     # path="/content/drive/MyDrive/Colab Notebooks/Utec"
#     # output_folder=os.path.join(path,"generated_images")
#     os.makedirs(output_folder, exist_ok=True)
#     for i in range(number_of_images):

#     # run both experts
#         image = base(
#             prompt=prompt,
#             num_inference_steps=n_steps,
#             denoising_end=high_noise_frac,
#             output_type="latent",
#         ).images
#         image = refiner(
#             prompt=prompt,
#             num_inference_steps=n_steps,
#             denoising_start=high_noise_frac,
#             image=image,
#         ).images[0]
#         image_path=os.path.join(output_folder, f"generated_image"+str(i+1)+".png")
#         image.save(image_path)


from flask import Flask, jsonify, request
from diffusers import DiffusionPipeline
import torch
import os

app = Flask(__name__)

# Initialize your models and parameters
n_steps = 40
high_noise_frac = 0.8
number_of_images = 1
output_folder = "../bk_image_folder"
os.makedirs(output_folder, exist_ok=True)

# Assuming base and refiner are initialized somewhere in your code
# For example:
# base = SomeBaseModel()
# refiner = SomeRefinerModel()
base = DiffusionPipeline.from_pretrained(
    "stabilityai/stable-diffusion-xl-base-1.0", torch_dtype=torch.float16, variant="fp16", use_safetensors=True
)
base.to("cuda")
refiner = DiffusionPipeline.from_pretrained(
    "stabilityai/stable-diffusion-xl-refiner-1.0",
    text_encoder_2=base.text_encoder_2,
    vae=base.vae,
    torch_dtype=torch.float16,
    use_safetensors=True,
    variant="fp16",
)
refiner.to("cuda")
@app.route('/generate-image', methods=['POST'])
def generate_image():
    data = request.get_json()

    if 'question' not in data:
        return jsonify({'error': 'Missing "question" parameter'}), 400

    question = data['question']

    prompt = "{}( without any texts)".format(question)
    # print(prompt,"aaaaaaaaaaaaaaaaaaaa")

    # Run both experts
    image = base(
        prompt=prompt,
        num_inference_steps=n_steps,
        denoising_end=high_noise_frac,
        output_type="latent",
    ).images
    image = refiner(
        prompt=prompt,
        num_inference_steps=n_steps,
        denoising_start=high_noise_frac,
        image=image,
    ).images[0]

    # Save the generated image
    image_path = os.path.join(output_folder, "generated_image.png")
    image.save(image_path)

    return jsonify({'image_path': image_path}), 200

if __name__ == '__main__':
    app.run(debug=True,port=5000,host="0.0.0.0")
