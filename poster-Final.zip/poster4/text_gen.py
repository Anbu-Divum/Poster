# import vertexai
# from vertexai.preview.generative_models import GenerativeModel, Part

# def generate():
#   model = GenerativeModel("gemini-pro")
#   responses = model.generate_content(
#     """i need the (title for the question ) in 3 words create a poster for Diwali""",
#     generation_config={
#         "max_output_tokens": 2048,
#         "temperature": 0.9,
#         "top_p": 1
#     },
#   stream=True,
#   )
  
#   for response in responses:
#       print(response.text, end="")
# generate()
import vertexai
from vertexai.language_models import TextGenerationModel

def generateTitle(question):
    vertexai.init(project="agileai-poc", location="us-central1")
    parameters = {
        "max_output_tokens": 1024,
        "temperature": 0.9,
        "top_p": 1
    }
    model = TextGenerationModel.from_pretrained("text-bison")
    response = model.predict(
        """i need the (title for the question ) in 3 words, {}""".format(question),
        **parameters
    )
    result=response.text
    print(f"Response for Title: {result}")
    return result
# generateTitle("Create a poster for diwali")


def generateQuotes(question):
    vertexai.init(project="agileai-poc", location="us-central1")
    parameters = {
        "max_output_tokens": 1024,
        "temperature": 0.9,
        "top_p": 1
    }
    model = TextGenerationModel.from_pretrained("text-bison")
    response = model.predict(
        """i need the (Quotes for the question ) in 10 words, {}""".format(question),
        **parameters
    )
    result=response.text
    print(f"Response for Quotes: {result}")
    return result
# generateQuotes("Create a poster for diwali")

