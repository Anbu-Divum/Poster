# ... (existing imports)
import argparse
import json
import cv2
import numpy as np
import os
from tqdm import tqdm
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# retrieve the background image based on given text.
# from background_retrieval import bk_img_retrieval
# Tool for write text on image.
from utils.font_utils import PutText2Image

# the layout distribution predict model.
from model.distrib_model import LayoutsDistribModel
# the layout refinement model.
from model.layout_model import BBoxesRegModel

# smooth region detection and predict the distribution of layout.
from layout_distribution_predict import smooth_region_dectection, get_distrib_mask

# refine the layout bounding boxxes.
from layout_refine import get_batch_text_region, get_bbox_mask, get_refine_bboxes

from text_gen import generateQuotes,generateTitle
# from img_gen import imgGenerate

import streamlit as st

import requests
st.title("POSTER DESIGN")


STD_WIDTH, STD_HEIGHT = 300, 400
MIN_VALUE = -999999
MAX_BBOX_NUM = 32

def get_user_input():
    image_path = input("Enter the path of the image: ")
    if not os.path.isfile(image_path):
        print("Invalid image path. Please try again.")
        return None
    return image_path

def generate_poster(user_images, user_text_input, output_folder,user_quotes):
    # Function to generate poster using user-provided images and text
    iteration_rounds = 30 
    font_file = "./font_files/Times New Roman.ttf"
    text_color = (255, 255, 255)
    ft_center = PutText2Image(font_file)

    if not os.path.exists(output_folder):
        os.mkdir(output_folder)

    sentences = [(user_text_input, 50),(user_quotes,20)]  # Assuming user provides one text input
    data_len = len(sentences)

    for i, img in enumerate(tqdm(user_images)):
        print(f"Generating poster {i + 1}...")

        width, height = img.shape[1], img.shape[0]
        img_size = (width, height)
        smooth_region_mask, regions, saliency_map = smooth_region_dectection(img)
        bbox_distrib_map = get_distrib_mask(smooth_region_mask)
        bbox_size_array = np.zeros((len(sentences), 2))

        for j, text_info in enumerate(sentences):
            bbox_size_array[j] = ft_center.get_text_bbox_size(text=text_info[0], text_size=text_info[1])

        initial_bboxes = get_batch_text_region(bbox_distrib_map, bbox_size_array, img_size)
        initial_bbox_mask = get_bbox_mask(initial_bboxes, data_len)

        initial_data = {"len_info": data_len,
                        "shifted_mask": initial_bbox_mask.copy(),
                        "shifted_bbox": initial_bboxes.copy(),
                        "bbox_distrib_map": bbox_distrib_map.copy(),
                        "smooth_region_mask": smooth_region_mask.copy()}

        refined_bboxes, refined_bbox_size, order = get_refine_bboxes(initial_data, iteration_rounds)
        refined_bbox_mask = get_bbox_mask(refined_bboxes[None, :], data_len)

        refined_bboxes[:, (0, 2)] = refined_bboxes[:, (0, 2)] / STD_WIDTH * width
        refined_bboxes[:, (1, 3)] = refined_bboxes[:, (1, 3)] / STD_HEIGHT * height

        bk_img = img.copy()
        bk_img = bk_img / 1.1
        bk_img = bk_img.astype(np.uint8)
        for j in range(len(sentences)):
            text_position = (refined_bboxes[j][0], refined_bboxes[j][1])
            text, text_size = sentences[order[j]][0], sentences[order[j]][1]
            bk_img = ft_center.draw_text(bk_img, text_position, text, text_size, text_color)

        save_folder = os.path.join(output_folder, f"poster_{i + 1}")
        if not os.path.exists(save_folder):
            os.mkdir(save_folder)
        poster_file = os.path.join(save_folder, "poster"+str(i+1)+".jpg")
        cv2.imwrite(poster_file, bk_img)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output_folder", type=str, dest="output_folder", default="example/outputs_user")
    parser.add_argument("--save_process", action='store_true')
    args = parser.parse_args()

    # Specify the image path directly in the code
    # img_path = "./bk_image_folder/3AanCrYzXN0.png"
    # FOLDER_PATH="bk_image_folder"
    # FILES=[file for file in os.listdir(FOLDER_PATH) if file.lower().endswith('.png')]

    # for i in FILES:
    # print(i)
    # break
    img_path = "./bk_image_folder/diwali.png"
    # img_path=FOLDER_PATH+"/"
    # The text for the poster
    l=[]
    form = st.form(key='my-form')
    User_input = form.text_input('Enter your text ')
    # print(User_input,"AAAAAAAAAAAAAAAAAAAaa")
    submit = form.form_submit_button('Submit')
    # User_input=input("Enter Your Question : ")
    # imgGenerate(User_input)
    if submit and User_input:
        url = "http://127.0.0.1:5000/generate-image"
        question_data = {"question": User_input}
        # response = requests.post(
        # url=url,
        # json=question_data
        # )
        # if response.status_code==200:
        user_text_input = generateTitle(User_input)

        user_quotes=generateQuotes(User_input)
        print(user_quotes)
        # Load the image
        img = cv2.imread(img_path)

        # Generate poster using the specified image and text
        generate_poster([img], user_text_input, args.output_folder,user_quotes)
        st.image("./example/outputs_user/poster_1/poster1.jpg")

if __name__ == "__main__":
    main()